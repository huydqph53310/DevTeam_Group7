<?php
// nhúng cái file cần thiết dành cho index để định hướng
include_once "Controller/AdminController/AdminController.php";
include_once "Controller/TrangChuController/TrangChuController.php";
include_once "Model/post/Connect.php";
include_once "Model/admin/DownData.php";
include_once "Model/admin/PostTopic.php";
include_once "Model/post/Config.php";
include_once "Model/user/User.php";
include_once "Model/user/CreateUser.php";
include_once "Model/user/Action.php";



/// sau khi nhúng sẽ check đưỡng dẫn trên thanh tìm kiếm bằng cách dùng lệnh gọi tên nó xuống
$search = "";
if (isset($_GET["@c"])) {
    $search = $_GET["@c"];
}

$TB = "";
if (isset($_GET["^s"])) {
    $TB = $_GET["^s"];
}
$id = "";
if (isset($_GET["a"])) {
    $id = $_GET["a"];
}
/// sau khi bắt keyword ở trên thanh tìm kiếm thì ta sẽ so sánh nó bằng switch

switch ($search) {
    case '': // rỗng thì auto vào trang chủ nhé
        header("location: ?@c=trangchu");
        break;
    case "trangchu":
        $ddController = new TrangChuController();
        $ddController->TrangChu();
        break;
    case "gioithieu":
        $ddController = new TrangChuController();
        $ddController->GioiThieu();
        break;
    case "diendan":
        $ddController = new TrangChuController();
        $ddController->DienDan();
        break;
    case "dangnhap":
        $ddController = new TrangChuController();
        $ddController->DangNhap();
        break;
    case "dangky":
        $ddController = new TrangChuController();
        $ddController->DangKy();
        break;
    case "dangxuat":
        $ddController = new TrangChuController();
        $ddController->DangXuat();
        break;
    case "donate":
        $ddController = new TrangChuController();
        $ddController->Donate();
        break;
    case "detail":
        $ddController = new TrangChuController();
        $ddController->DetailPost($id);
        break;
    case "tb":
        $ddController = new TrangChuController();
        $ddController->ThongBao($TB, $id);
        break;
    default:
        # code...
        break;
}
